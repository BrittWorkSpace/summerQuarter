/*
   Index Style Sheet
   
   Author: Michael Britt
   Date:   5/30/2018
   
   Filename: slideshow.css

*/

var slideIndex = 0;
slideshow();

function slideshow() {
    var i;
    var x = document.getElementsByClassName("slide");
    for (i = 0; i < x.length; i++) {
      x[i].style.display = "none"; 
    }
    slideIndex++;
    if (slideIndex > x.length) {slideIndex = 1} 
    x[slideIndex-1].style.display = "block"; 
    setTimeout(slideshow, 3000);
}
